# Production deployment guide for scheduleconnected.com

## Prerequisites
- Domain **scheduleconnected.com** registered and under your control
- Hosting account (Render, Railway, Fly.io, DigitalOcean, etc.)

## Recommended: Deploy to Render (free tier available)

1. Push the code to a GitHub repository (create one and upload the `auth_mvp` folder).

2. Go to https://render.com and create a **New Web Service**.

3. Connect your GitHub repo.

4. Settings:
   - **Environment**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn run:app --bind 0.0.0.0:$PORT`
   - **Environment Variables**:
     - `FLASK_SECRET_KEY` = (generate a long random string, e.g. `openssl rand -hex 32`)
     - `FLASK_ENV` = `production`
     - `DATABASE_URL` = (optional; Render provides Postgres, or leave for SQLite)

5. Deploy. Render gives you a URL like `https://your-app.onrender.com`.

6. **Connect the domain**:
   - In Render → your service → Settings → Custom Domains → Add `scheduleconnected.com` and `www.scheduleconnected.com`.
   - Render will give you DNS records (usually CNAME or A record).
   - At your domain registrar (GoDaddy, Namecheap, Cloudflare, etc.), update DNS:
     - Point `scheduleconnected.com` to the Render target.
     - Wait for DNS propagation (minutes to hours).
   - Render will automatically provision an SSL certificate.

## Alternative: Railway
- Similar process at https://railway.app
- Add custom domain in the project settings and update DNS.

## Alternative: VPS (DigitalOcean, Linode, etc.)
1. Create a Ubuntu droplet.
2. Install Python, nginx, certbot.
3. Clone/upload the app.
4. Use Gunicorn + Nginx reverse proxy.
5. Point domain A record to the server IP.
6. Run `certbot --nginx` for free SSL.

## Environment variables (required for production)
- `FLASK_SECRET_KEY` — long random string
- `FLASK_ENV=production` (enables secure cookies)
- Optional: `DATABASE_URL` for PostgreSQL

## After deployment
Visit https://scheduleconnected.com — you should see the login page.

## Notes
- SQLite works for low traffic but is not ideal for production multi-user. Switch to Postgres when ready.
- Change the default secret key before going live.
- The app is modular; you can keep adding features after it is live.
